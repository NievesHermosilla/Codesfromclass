
package com.example.day19;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;

public class MainActivity1 extends AppCompatActivity {
    private ActivityResultLauncher<Intent> someActivityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);

        ImageView imageView = findViewById(R.id.imageView);
        String imageUrl = "https://unsplash.com/photos/a-bottle-of-blue-liquid-next-to-a-rock-RMUSYeC4r5I.jpg";

        Picasso.get()
                .load(imageUrl)
                .into(imageView);

        Button openButton = findViewById(R.id.openButton);

        openButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to open ImportContactsActivity
                Intent intent = new Intent(MainActivity1.this, ContactsView.class);
                startActivity(intent);
            }
        });

        Button viewContactsButton = findViewById(R.id.viewContactsButton);

        viewContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSomeActivityForResult();
            }
        });

        someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            Intent data = result.getData();
                            String selectedName = data.getStringExtra("selectedName");
                            String selectedPhoneNumber = data.getStringExtra("selectedPhoneNumber");
                            Log.e("badjoras", "name: " + selectedName);
                            // Handle the selected contact's name and phone number as needed
                        }
                    }
                });

        Button button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity1.this, WebViewActivity.class);
                startActivity(intent);
            }
        });
    }

    private void openSomeActivityForResult() {
        Intent intent = new Intent(this, ContactListActivity.class);
        someActivityResultLauncher.launch(intent);
    }
}


/*

    Button viewContactsButton = findViewById(R.id.viewContactsButton);

        viewContactsButton.setOnClickListener(new View.OnClickListener(){
@Override
public void onClick(View v){
        openSomeActivityForResult();
        }
        });

        someActivityResultLauncher=registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>(){
@Override
public void onActivityResult(ActivityResult result){
        if(result.getResultCode()==RESULT_OK){
        Intent data=result.getData();
        String selectedName=data.getStringExtra("selectedName");
        String selectedPhoneNumber=data.getStringExtra("selectedPhoneNumber");
        // Handle the selected contact's name and phone number as needed
        }
        }
        });

        Button button=findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener(){
@Override
public void onClick(View v){
        Intent intent=new Intent(MainActivity1.this,WebViewActivity.class);
        startActivity(intent);
        }
        });
        }

private void openSomeActivityForResult(){
        Intent intent=new Intent(this,ContactListActivity.class);
        someActivityResultLauncher.launch(intent);
        }
        }
*/
