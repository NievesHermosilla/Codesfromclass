package com.example.day19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ContactListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ContactsAdapter contactsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                null,
                null,
                null
        );

        contactsAdapter = new ContactsAdapter(cursor, new ContactsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String name, String phoneNumber) {
                returnToMainActivityWithContactDetails(name, phoneNumber);
            }
        });

        recyclerView.setAdapter(contactsAdapter);
    }

    private void returnToMainActivityWithContactDetails(String name, String phoneNumber) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("selectedName", name);
        resultIntent.putExtra("selectedPhoneNumber", phoneNumber);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}




